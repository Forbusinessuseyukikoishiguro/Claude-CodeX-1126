"""④ E2Eスモーク: 実際に claude / codex を非対話で起動し、スキル経由で成果物ができるかを見る。

判定は「エージェントの返答文」ではなく「成果物(xlsx)」で行う:
  - A1 に今回だけの乱数トークンが入っている            → 作業が完了した
  - ブックの作成者が excel_tool のマーカーになっている  → スキルのスクリプトが実際に使われた

非対話実行の根拠:
- Codex  : `codex exec` は既定が read-only sandbox。編集には --sandbox workspace-write、
           Gitリポジトリ外では --skip-git-repo-check が必要（--full-auto は非推奨）
           https://developers.openai.com/ の Codex「Non-interactive mode」
- Claude : `claude -p` で非対話。--allowedTools / --permission-mode で事前許可、--output-format json
  ※フラグはバージョンで変わる。失敗時は `claude --help` / `codex exec --help` で手元の版を確認する。
実行: python -m pytest -m e2e -v     (環境変数 E2E_RETRIES, E2E_TIMEOUT, E2E_AGENTS=claude,codex)
"""
import json
import os
import shutil
import subprocess
import uuid

import openpyxl
import pytest

from conftest import ROOT

pytestmark = pytest.mark.e2e

SKILL = "python-excel-spec"
MARKER = "python-excel-spec/excel_tool 1.0"
OUT = ROOT / ".e2e_out"
TIMEOUT = int(os.getenv("E2E_TIMEOUT", "300"))
RETRIES = int(os.getenv("E2E_RETRIES", "1"))  # 失敗時の再試行回数（LLMは確率的なので）
AGENTS = [a.strip() for a in os.getenv("E2E_AGENTS", "claude,codex").split(",") if a.strip()]

PROMPTS = {
    # 名指し: スキル名を明示。スキルが発見・実行できるかを見る
    "named": "{skill} スキルを使って、{rel} の A1 に {token} を書き込み、読み戻して確認してください。終わったら DONE とだけ答えて。",
    # 暗黙: スキル名を出さない。description だけで選ばれるか（トリガー品質）を見る
    "implicit": "Excelファイル {rel} を新規作成し、A1 に {token} を入れて保存してください。終わったら DONE とだけ答えて。",
}


def command(agent, prompt):
    if agent == "claude":
        return ["claude", "-p", prompt,
                "--permission-mode", "acceptEdits",
                "--allowedTools", "Bash(python *)", "Bash(python3 *)", "Bash(py *)", "Read",
                "--output-format", "json"]
    return ["codex", "exec", "--sandbox", "workspace-write", "--skip-git-repo-check", prompt]


def run_once(agent, mode):
    token = uuid.uuid4().hex[:10]
    OUT.mkdir(exist_ok=True)
    rel = f".e2e_out/{agent}_{mode}_{token}.xlsx"
    prompt = PROMPTS[mode].format(skill=SKILL, rel=rel, token=token)
    proc = subprocess.run(command(agent, prompt), cwd=ROOT, capture_output=True, text=True,
                          encoding="utf-8", timeout=TIMEOUT)
    (OUT / f"{agent}_{mode}_{token}.log").write_text(
        f"$ {' '.join(command(agent, prompt))}\n\n[stdout]\n{proc.stdout}\n\n[stderr]\n{proc.stderr}", encoding="utf-8")
    target = ROOT / rel
    problems = []
    if proc.returncode != 0:
        problems.append(f"終了コード {proc.returncode}")
    if not target.exists():
        problems.append("成果物がありません")
    else:
        wb = openpyxl.load_workbook(target)
        if wb.active["A1"].value != token:
            problems.append(f"A1 が期待値と違う: {wb.active['A1'].value!r}")
        if wb.properties.creator != MARKER:
            problems.append("スキルのスクリプトが使われていません（エージェントが自前コードで作成した可能性）")
    if agent == "claude":
        try:
            denials = json.loads(proc.stdout).get("permission_denials") or []
            if denials:
                problems.append(f"許可拒否あり: {denials}")
        except (ValueError, AttributeError):
            pass
    return problems


@pytest.mark.parametrize("mode", ["named", "implicit"])
@pytest.mark.parametrize("agent", AGENTS)
def test_agent_uses_skill(agent, mode):
    if shutil.which(agent) is None:
        pytest.skip(f"{agent} CLI が見つかりません")
    last = []
    for _ in range(RETRIES + 1):
        last = run_once(agent, mode)
        if not last:
            return
    pytest.fail(f"{agent}/{mode} が {RETRIES + 1} 回連続で失敗: {last}（ログ: .e2e_out/）")


def test_record_versions():
    """再現性のため、テスト時点の CLI バージョンを記録する。"""
    OUT.mkdir(exist_ok=True)
    lines = []
    for agent in AGENTS:
        if shutil.which(agent):
            r = subprocess.run([agent, "--version"], capture_output=True, text=True, encoding="utf-8")
            lines.append(f"{agent}: {r.stdout.strip() or r.stderr.strip()}")
    (OUT / "versions.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
