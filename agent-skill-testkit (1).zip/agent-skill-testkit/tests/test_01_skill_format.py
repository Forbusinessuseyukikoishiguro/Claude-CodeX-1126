"""① 形式テスト（エージェント不要）

根拠:
- Agent Skills 仕様 https://agentskills.io/specification
    name: 必須 / 1-64文字 / 小文字・数字・ハイフンのみ / 先頭末尾ハイフン不可 / 連続ハイフン不可 / 親ディレクトリ名と一致
    description: 必須 / 1-1024文字
    任意項目: license, compatibility, metadata, allowed-tools
    参照ファイルは SKILL.md から1階層まで
- Codex https://developers.openai.com/codex/skills : SKILL.md に name と description が必須、
    agents/openai.yaml は任意
- Claude Code https://code.claude.com/docs/en/skills : 標準を拡張する独自項目があり、
    フォルダ名 synced は予約
"""
import re

import pytest
import yaml

from conftest import SKILLS_DIR

STANDARD_KEYS = {"name", "description", "license", "compatibility", "metadata", "allowed-tools"}
CLAUDE_CODE_EXTENSIONS = {"argument-hint", "disable-model-invocation", "user-invocable", "context"}
NAME_RE = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")
FRONTMATTER_RE = re.compile(r"\A---\r?\n(.*?)\r?\n---\r?\n?(.*)\Z", re.S)
RESERVED_WORDS = ("anthropic", "claude")  # Anthropicのスキル作成ガイドの予約語

SKILL_DIRS = sorted(p for p in SKILLS_DIR.iterdir() if p.is_dir() and not p.name.startswith("."))


def load(skill_dir):
    raw = (skill_dir / "SKILL.md").read_text(encoding="utf-8-sig")
    m = FRONTMATTER_RE.match(raw)
    assert m, "SKILL.md の先頭が --- で囲まれた frontmatter になっていません"
    meta = yaml.safe_load(m.group(1))
    assert isinstance(meta, dict), "frontmatter が YAML の辞書ではありません"
    return meta, m.group(2), raw


def test_at_least_one_skill():
    assert SKILL_DIRS, f"{SKILLS_DIR} にスキルがありません"


@pytest.fixture(params=SKILL_DIRS, ids=lambda p: p.name)
def skill(request):
    d = request.param
    assert (d / "SKILL.md").is_file(), "SKILL.md がありません（大文字小文字も厳密に）"
    return d, *load(d)


def test_name_rules(skill):
    d, meta, _, _ = skill
    name = meta.get("name")
    assert isinstance(name, str), "name は必須の文字列です"
    assert 1 <= len(name) <= 64, f"name は1-64文字: {len(name)}"
    assert NAME_RE.match(name), f"name は小文字・数字・単一ハイフンのみ: {name!r}"
    assert name == d.name, f"name({name}) とディレクトリ名({d.name}) が不一致"
    assert not any(w in name for w in RESERVED_WORDS), f"name に予約語を含められません: {name}"
    assert name.lower() != "synced", "Claude Code が予約している名前です"


def test_description_rules(skill):
    _, meta, _, _ = skill
    desc = meta.get("description")
    assert isinstance(desc, str) and desc.strip(), "description は必須で空にできません"
    assert len(desc) <= 1024, f"description は1024文字以内: {len(desc)}"


def test_only_portable_keys(skill):
    """両エージェント共通で読めるよう、標準項目だけに限定する。"""
    _, meta, _, _ = skill
    extra = set(meta) - STANDARD_KEYS
    claude_only = sorted(extra & CLAUDE_CODE_EXTENSIONS)
    other = sorted(extra - CLAUDE_CODE_EXTENSIONS)
    assert not extra, (
        f"標準外の項目があります。Claude Code独自: {claude_only} / その他: {other}。"
        " Codex側の同等設定は agents/openai.yaml に分離してください。"
    )


def test_optional_field_shapes(skill):
    _, meta, _, _ = skill
    if "compatibility" in meta:
        assert isinstance(meta["compatibility"], str) and 1 <= len(meta["compatibility"]) <= 500
    if "metadata" in meta:
        assert isinstance(meta["metadata"], dict)
        assert all(isinstance(k, str) and isinstance(v, str) for k, v in meta["metadata"].items()), \
            "metadata は 文字列→文字列 のみ（バージョンは \"1.0\" のように引用符で囲む）"
    if "allowed-tools" in meta:
        assert isinstance(meta["allowed-tools"], str), "allowed-tools は空白区切りの文字列（標準）"
    if "license" in meta:
        assert isinstance(meta["license"], str)


def test_body_not_empty_and_reasonable(skill):
    _, _, body, raw = skill
    assert body.strip(), "本文が空です（スタブ）"
    assert len(raw.splitlines()) <= 500, "SKILL.md は500行以内を推奨（詳細は references/ へ）"


def test_referenced_files_exist_and_stay_inside(skill):
    d, _, body, _ = skill
    assert "../" not in body, "スキル外（../）への参照は避ける。参照は SKILL.md から1階層まで"
    refs = {r.rstrip(".,)") for r in re.findall(r"(?<![\w/.-])((?:scripts|references|assets)/[\w./-]+)", body)}
    for rel in sorted(refs):
        assert (d / rel).exists(), f"本文が参照するファイルがありません: {rel}"


def test_script_runs_with_help(skill):
    """scripts/ 内の .py は --help で終了コード0になる（構文エラー・依存欠落の検出）。"""
    import subprocess
    import sys

    d, _, _, _ = skill
    for script in sorted((d / "scripts").glob("*.py")) if (d / "scripts").is_dir() else []:
        r = subprocess.run([sys.executable, str(script), "--help"], capture_output=True, text=True, encoding="utf-8")
        assert r.returncode == 0, f"{script.name} --help が失敗: {r.stderr}"


def test_codex_openai_yaml_is_valid_if_present(skill):
    d, _, _, _ = skill
    f = d / "agents" / "openai.yaml"
    if f.exists():
        data = yaml.safe_load(f.read_text(encoding="utf-8"))
        assert isinstance(data, dict), "agents/openai.yaml は YAML の辞書にしてください"


def test_names_are_unique():
    names = [load(d)[0].get("name") for d in SKILL_DIRS]
    assert len(names) == len(set(names)), f"name が重複: {names}（Codexは同名をマージしない）"
