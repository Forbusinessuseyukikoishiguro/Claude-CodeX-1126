"""手動テスト補助スクリプト（prepare / verify）が壊れていないことの自動テスト。"""
import json
import os
import shutil
import subprocess
import sys

import pytest

from conftest import ROOT, SKILLS_DIR

TOOL = SKILLS_DIR / "python-excel-spec" / "scripts" / "excel_tool.py"


OUT_NAME = ".manual_out_test"  # 実施中の手動テスト(.manual_out)を壊さないため別ディレクトリを使う
ENV = {**os.environ, "MANUAL_OUT_DIR": OUT_NAME}


def py(*args):
    return subprocess.run([sys.executable, *map(str, args)], cwd=ROOT, capture_output=True, text=True,
                          encoding="utf-8", env=ENV)


@pytest.fixture(autouse=True)
def prepared():
    assert py("scripts/prepare_manual.py").returncode == 0
    yield
    shutil.rmtree(ROOT / OUT_NAME, ignore_errors=True)


def tokens():
    return json.loads((ROOT / OUT_NAME / "tokens.json").read_text(encoding="utf-8"))


def test_prepare_creates_tokens_for_all_cases():
    t = tokens()
    for cid in ("M-03", "M-04", "M-06", "M-07"):
        for agent in ("claude", "codex"):
            assert t[cid][agent]["prompt"]


def test_verify_pass_when_skill_script_used():
    info = tokens()["M-03"]["claude"]
    assert py(TOOL, "write", ROOT / info["file"], "A1", info["value"]).returncode == 0
    r = py("scripts/verify_manual.py", "M-03", "claude")
    assert r.returncode == 0 and "PASS" in r.stdout


def test_verify_fails_when_agent_wrote_file_itself():
    import openpyxl

    info = tokens()["M-04"]["codex"]
    wb = openpyxl.Workbook()
    wb.active["A1"] = info["value"]  # 値は合っているがスクリプトを使っていない
    wb.save(ROOT / info["file"])
    r = py("scripts/verify_manual.py", "M-04", "codex")
    assert r.returncode == 1 and "使われていません" in r.stdout


def test_verify_fails_when_value_wrong_or_missing():
    assert py("scripts/verify_manual.py", "M-03", "codex").returncode == 1  # 成果物なし
    info = tokens()["M-07"]["claude"]
    py(TOOL, "write", ROOT / info["file"], "A1", "違う値")
    assert py("scripts/verify_manual.py", "M-07", "claude").returncode == 1


def test_m06_fails_if_file_fabricated():
    assert py("scripts/verify_manual.py", "M-06", "claude").returncode == 0
    info = tokens()["M-06"]["claude"]
    py(TOOL, "write", ROOT / info["file"], "A1", "捏造")
    assert py("scripts/verify_manual.py", "M-06", "claude").returncode == 1
