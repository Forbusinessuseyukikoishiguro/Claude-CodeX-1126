"""③ 配置テスト（エージェント不要）

根拠:
- Codex: リポジトリの .agents/skills を探索。シンボリックリンクの実体を辿る
  https://developers.openai.com/codex/skills
- Claude Code: .claude/skills/<name>/SKILL.md を探索。リンクは実体を1回だけ読み込む
  https://code.claude.com/docs/en/skills
"""
import hashlib

from conftest import ROOT, SKILLS_DIR

CLAUDE_SKILLS = ROOT / ".claude" / "skills"


def digest(base):
    h = hashlib.sha256()
    for p in sorted(base.rglob("*")):
        if p.is_file() and "__pycache__" not in p.parts:
            h.update(str(p.relative_to(base)).replace("\\", "/").encode())
            h.update(p.read_bytes())
    return h.hexdigest()


def test_claude_skills_dir_exists():
    assert CLAUDE_SKILLS.exists(), "`python scripts/sync_claude_links.py` を実行して .claude/skills を作ってください"


def test_claude_view_equals_codex_view():
    """リンクでもコピーでも、Claude側とCodex側のスキルの中身が一致している。"""
    assert digest(CLAUDE_SKILLS) == digest(SKILLS_DIR), ".claude/skills と .agents/skills の内容が不一致（コピー運用なら再同期を）"


def test_each_skill_visible_from_claude_path():
    for d in SKILLS_DIR.iterdir():
        if d.is_dir():
            assert (CLAUDE_SKILLS / d.name / "SKILL.md").is_file()


def test_instruction_files_for_fallback():
    assert (ROOT / "AGENTS.md").is_file(), "Codex用の AGENTS.md がありません"
    claude_md = ROOT / "CLAUDE.md"
    assert claude_md.is_file(), "Claude Code用の CLAUDE.md がありません"
    assert "@AGENTS.md" in claude_md.read_text(encoding="utf-8"), "CLAUDE.md は @AGENTS.md を読み込む形にして指示の二重管理を避ける"
