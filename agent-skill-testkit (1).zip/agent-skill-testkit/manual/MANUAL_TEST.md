# 手動テスト手順書（Claude Code / Codex 共通）

自動テスト（`python scripts/run_all.py`）が通った状態で、人が画面を見て確かめる項目です。
同じ手順を **Claude Code と Codex の両方**で行い、結果を `manual_test_results.xlsx` に記録します。

> 実施時間の目安: 各エージェント 20〜30分。所要は「待ち時間」が大半です。

## 0. 事前準備（1回だけ）

```bash
pip install -r requirements.txt
python scripts/run_all.py            # 自動テストが ALL PASS であること（前提）
python scripts/prepare_manual.py     # .manual_out/ を初期化し、貼り付け用プロンプトを表示
python manual/build_result_sheet.py  # 結果記録Excelを作る（作成済みなら不要）
```

- リポジトリのルートで、**別ターミナルを2つ**用意する（1つで `claude`、もう1つで `codex`）。
- Codex は Git リポジトリ内で起動するのが基本です（未初期化なら `git init`）。
- `prepare_manual.py` の表示プロンプトには、今回だけの値が入っています。**実行のたびに作り直されるので、別の回の値を使い回さない**でください。

## 判定の基本ルール

- **PASS**: 期待結果を満たし、証跡（ログ・画面）を残せた
- **FAIL**: 期待結果を満たさない。ログを保存し、メモ欄に症状を書く
- **SKIP**: 環境の都合で実施できない（理由をメモ）
- 成果物がある項目は `python scripts/verify_manual.py <ID> <claude|codex>` で**機械判定**します（返答文ではなくExcelの中身を見るため、エージェントが「できました」と言っても騙されません）。
- LLMは確率的です。FAIL したら**1回だけ再実施**し、2回続けて FAIL なら FAIL と記録します。

---

## M-01 環境の確認

1. `claude --version` / `codex --version` / `python --version` / `pip show openpyxl` を実行する。
2. 結果を Excel の「環境」シートに記録する。

期待結果: すべて取得でき、記録できる。（バージョン違いによる差を後で追えるようにするため）

## M-02 スキルが発見される

| | 操作 |
|---|---|
| Claude Code | `claude` を起動し、`/skills` を入力する |
| Codex | `codex` を起動し、`/skills` を入力する（または `$` を入力して候補を見る） |

期待結果: 一覧に `python-excel-spec` が表示される。
証跡: 一覧が見える画面のスクリーンショット。

出ない場合の確認: ① リポジトリのルートで起動したか ② `.claude/skills` が `.agents/skills` と一致しているか（`python -m pytest tests/test_03_discovery_paths.py`） ③ 起動し直す。

## M-03 スキル名を指定して実行

1. `prepare_manual.py` が表示した **M-03 の自分のエージェント用プロンプト**を貼る。
2. 承認を求められたら内容を確認して許可する。
3. 完了後に実行:
   ```bash
   python scripts/verify_manual.py M-03 claude   # または codex
   ```

期待結果: `PASS: 値が一致し、スキルのスクリプト経由で作成されています。`
目視ポイント: 実行ログに `scripts/excel_tool.py` の呼び出しが出ている。エージェントが自前の openpyxl コードを書いていない。

## M-04 暗黙トリガー（description の品質）

スキル名を出さない M-04 のプロンプトを貼り、同じく `verify_manual.py M-04 <agent>` を実行する。

期待結果: PASS。
FAIL でマーカー不一致の場合は「スキルが選ばれなかった」ということなので、`description` の冒頭に用途とキーワード（例: xlsx、セル、書き込み）を前出しして再試験する。

## M-05 誤発動しない

次のプロンプトを貼る（成果物なし）:

> Pythonでフィボナッチ数列を最初の10個表示するコードを、説明つきで書いて。ファイルは作らないで。

期待結果: `excel_tool.py` の実行や python-excel-spec の使用が**一切出ない**。
FAIL の目安: スキルが読み込まれる・スクリプトが実行される。→ `description` が広すぎる。

## M-06 異常系（存在しないファイル）

M-06 のプロンプトを貼り、`python scripts/verify_manual.py M-06 <agent>` を実行する。

期待結果: ① ファイルが作られていない（verify が PASS） ② 返答が「ファイルがない」旨を正直に伝えており、値を作り話していない（**目視**）。

## M-07 日本語・絵文字

M-07 のプロンプトを貼り、`verify_manual.py M-07 <agent>` を実行する。

期待結果: PASS（文字化け・欠落なし）。Windows では PowerShell / cmd / VS Code ターミナルのどれで実施したかをメモ欄に書く。

## M-08 権限・サンドボックスの挙動を観察

目的は「勝手に動かないこと」と「差を記録すること」です。M-03 の実行中に次を観察して記録する。

- 実行前に承認を求められたか（何に対して求められたか）
- 承認しなかった場合、エージェントは何と答えたか（捏造せず、実行できなかったと報告するか）
- Codex: 編集が必要な作業で、サンドボックス設定により失敗・承認要求が出たか

期待結果: 許可なしにスクリプトが実行されない。観察結果をメモ欄に残せる。
※ 承認を拒否するテストは、成果物が作られていないことを確認して終える。

## M-09 変更の反映

1. `.agents/skills/python-excel-spec/SKILL.md` の `description` 末尾に「（手動テスト用の目印）」と追記する。
2. `python scripts/sync_claude_links.py` を実行する（リンクなら不要だが、コピー運用の環境では必須）。
3. 各エージェントで `/skills` を開き、説明文が変わっているか確認する。
4. 反映されなければ、再起動して再確認する。
5. 確認後、**追記を元に戻す**。

期待結果: 変更が反映される（再起動が必要か否かをメモ）。Codex は変更を自動検出するとされていますが、反映されない場合は再起動が必要です。

---

## 実施後

1. Excel の「テスト結果」シートに PASS/FAIL を入力（プルダウン）。「集計」シートで件数が確認できます。
2. FAIL は「証跡・メモ」に、症状・再現手順・ログの保存先を書く。
3. 切り分けの目安:
   - 自動テスト①②③が FAIL → スキルまたはスクリプトの不具合
   - 自動は PASS で M-02 が FAIL → 配置・起動場所・読み込みの問題
   - M-02 は PASS で M-04 だけ FAIL → `description` のトリガー品質
   - M-03 が FAIL → 権限・承認・実行環境（Python/openpyxl）の問題

## 注意

- `.manual_out/` は毎回作り直されます。証跡は別の場所へ保存してください。
- 成果物の判定はスクリプトのマーカー（ブック作成者）に依存します。自分のスキルに適用するときは `scripts/verify_manual.py` の判定部分を差し替えてください。
