#!/usr/bin/env python3
"""結果記録Excelを作る: python manual/build_result_sheet.py  → manual/manual_test_results.xlsx"""
from pathlib import Path

from openpyxl import Workbook
from openpyxl.formatting.rule import CellIsRule
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.worksheet.datavalidation import DataValidation

CASES = [
    ("M-01", "環境", "バージョン・Python・openpyxl の確認と記録", "各バージョンが「環境」シートに記録できる", "手順書 M-01"),
    ("M-02", "発見", "スキル一覧に python-excel-spec が出る（/skills）", "両エージェントの一覧に表示される", "手順書 M-02"),
    ("M-03", "実行", "スキル名を指定して書き込み", "verify が PASS（値一致＋マーカー）", "verify_manual.py M-03"),
    ("M-04", "トリガー", "スキル名を出さずに依頼", "スキルが自動で選ばれ、verify が PASS", "verify_manual.py M-04"),
    ("M-05", "誤発動", "無関係な依頼でスキルが動かない", "excel_tool が実行されない", "手順書 M-05（目視）"),
    ("M-06", "異常系", "存在しないファイルを読ませる", "失敗を正直に報告し、値を捏造しない", "verify_manual.py M-06＋目視"),
    ("M-07", "文字コード", "日本語・絵文字の書き込み", "verify が PASS（文字化けなし）", "verify_manual.py M-07"),
    ("M-08", "権限", "実行前の承認/サンドボックスの挙動を観察", "許可なしにスクリプトが走らず、挙動を記録できる", "手順書 M-08（目視）"),
    ("M-09", "変更反映", "description を編集 → 一覧に反映", "再起動の要否を含め反映を確認", "手順書 M-09（目視）"),
]
HEAD = ["ID", "観点", "内容", "期待結果", "確認方法", "Claude Code", "Codex", "証跡・メモ（ログ/画面の保存先）", "実施日", "実施者"]


def main():
    wb = Workbook()
    ws = wb.active
    ws.title = "テスト結果"
    ws.append(HEAD)
    for c in CASES:
        ws.append([*c, "", "", "", "", ""])
    widths = [7, 10, 40, 40, 28, 13, 13, 40, 12, 12]
    for i, w in enumerate(widths):
        ws.column_dimensions[chr(65 + i)].width = w
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="2F5597")
    for row in ws.iter_rows(min_row=1):
        for cell in row:
            cell.alignment = Alignment(wrap_text=True, vertical="top")
    last = len(CASES) + 1
    dv = DataValidation(type="list", formula1='"PASS,FAIL,SKIP,未実施"', allow_blank=True)
    ws.add_data_validation(dv)
    dv.add(f"F2:G{last}")
    for r in range(2, last + 1):
        ws[f"F{r}"] = ws[f"G{r}"] = "未実施"
    rng = f"F2:G{last}"
    ws.conditional_formatting.add(rng, CellIsRule(operator="equal", formula=['"PASS"'], fill=PatternFill("solid", bgColor="C6EFCE")))
    ws.conditional_formatting.add(rng, CellIsRule(operator="equal", formula=['"FAIL"'], fill=PatternFill("solid", bgColor="FFC7CE")))
    ws.freeze_panes = "A2"

    s = wb.create_sheet("集計")
    s.append(["結果", "Claude Code", "Codex"])
    for label in ["PASS", "FAIL", "SKIP", "未実施"]:
        r = s.max_row + 1
        s.append([label, f'=COUNTIF(テスト結果!F2:F{last},A{r})', f'=COUNTIF(テスト結果!G2:G{last},A{r})'])
    for cell in s[1]:
        cell.font = Font(bold=True)
    s.column_dimensions["A"].width = 10
    s.column_dimensions["B"].width = 14
    s.column_dimensions["C"].width = 14

    e = wb.create_sheet("環境")
    e.append(["項目", "Claude Code 側", "Codex 側"])
    for item in ["OS / シェル", "CLIバージョン（claude --version / codex --version）", "Python（python --version）",
                 "openpyxl（pip show openpyxl）", "実施したモデル/プラン", "実施日時", "キット版（git rev-parse --short HEAD など）"]:
        e.append([item, "", ""])
    for cell in e[1]:
        cell.font = Font(bold=True)
    e.column_dimensions["A"].width = 46
    e.column_dimensions["B"].width = 30
    e.column_dimensions["C"].width = 30

    out = Path(__file__).with_name("manual_test_results.xlsx")
    wb.save(out)
    print(out)


if __name__ == "__main__":
    main()
