#!/usr/bin/env python3
"""excel_tool.py - 小さなExcel操作CLI（openpyxl）。

成功: JSONを標準出力へ、終了コード0
失敗: {"ok": false, "error": ...} を標準エラーへ、終了コード1（想定内の失敗）
引数エラー: argparseが終了コード2
"""
import argparse
import json
import sys
from pathlib import Path

from openpyxl import Workbook, load_workbook

MARKER = "python-excel-spec/excel_tool 1.0"  # 「このスクリプトで書いた」ことの証跡


def emit(obj, stream=None):
    (stream or sys.stdout).write(json.dumps(obj, ensure_ascii=False) + "\n")


def fail(message):
    emit({"ok": False, "error": message}, sys.stderr)
    return 1


def convert(value, kind):
    if kind == "int":
        return int(value)
    if kind == "float":
        return float(value)
    return value


def cmd_write(args):
    path = Path(args.file)
    try:
        value = convert(args.value, args.as_type)
    except ValueError:
        return fail(f"値を {args.as_type} に変換できません: {args.value!r}")
    if path.exists():
        wb = load_workbook(path)
        ws = wb[args.sheet] if args.sheet in wb.sheetnames else wb.create_sheet(args.sheet)
    else:
        wb = Workbook()
        ws = wb.active
        ws.title = args.sheet
    try:
        ws[args.cell] = value
    except Exception as exc:  # 不正なセル番地など
        return fail(f"セルに書き込めません: {args.cell!r} ({exc})")
    wb.properties.creator = MARKER
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)
    emit({"ok": True, "file": str(path), "sheet": args.sheet, "cell": args.cell, "value": value})
    return 0


def cmd_read(args):
    path = Path(args.file)
    if not path.exists():
        return fail(f"ファイルがありません: {path}")
    wb = load_workbook(path)
    if args.sheet not in wb.sheetnames:
        return fail(f"シートがありません: {args.sheet!r} (あるシート: {wb.sheetnames})")
    try:
        value = wb[args.sheet][args.cell].value
    except Exception as exc:
        return fail(f"セルを読めません: {args.cell!r} ({exc})")
    emit({"ok": True, "sheet": args.sheet, "cell": args.cell, "value": value})
    return 0


def cmd_sheets(args):
    path = Path(args.file)
    if not path.exists():
        return fail(f"ファイルがありません: {path}")
    emit({"ok": True, "sheets": load_workbook(path).sheetnames})
    return 0


def build_parser():
    p = argparse.ArgumentParser(description="小さなExcel操作CLI")
    sub = p.add_subparsers(dest="command", required=True)

    w = sub.add_parser("write", help="セルに値を書き込む")
    w.add_argument("file")
    w.add_argument("cell")
    w.add_argument("value")
    w.add_argument("--sheet", default="Sheet1")
    w.add_argument("--as", dest="as_type", choices=["str", "int", "float"], default="str")
    w.set_defaults(func=cmd_write)

    r = sub.add_parser("read", help="セルの値を読む")
    r.add_argument("file")
    r.add_argument("cell")
    r.add_argument("--sheet", default="Sheet1")
    r.set_defaults(func=cmd_read)

    s = sub.add_parser("sheets", help="シート名の一覧")
    s.add_argument("file")
    s.set_defaults(func=cmd_sheets)
    return p


def main(argv=None):
    for stream in (sys.stdout, sys.stderr):  # Windowsでも日本語を化けさせない
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8")
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
