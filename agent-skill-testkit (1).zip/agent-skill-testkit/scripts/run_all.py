#!/usr/bin/env python3
"""一括実行: python scripts/run_all.py [--e2e]

  1) .claude/skills を同期
  2) ①形式 ②Python ③配置 の各テスト（エージェント不要）
  3) --e2e 指定時のみ ④実エージェントのスモーク
終了コードは全て通れば 0。
"""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def sh(*cmd):
    print("\n$", " ".join(cmd), flush=True)
    return subprocess.run(cmd, cwd=ROOT).returncode


def main():
    rc = sh(sys.executable, "scripts/sync_claude_links.py")
    rc |= sh(sys.executable, "-m", "pytest", "-q")
    if "--e2e" in sys.argv:
        rc |= sh(sys.executable, "-m", "pytest", "-m", "e2e", "-v")
    print("\n結果:", "ALL PASS" if rc == 0 else "FAILED")
    return 1 if rc else 0


if __name__ == "__main__":
    sys.exit(main())
