#!/usr/bin/env python3
"""手動テストの準備: python scripts/prepare_manual.py

- .manual_out/（環境変数 MANUAL_OUT_DIR で変更可）を初期化し、.claude/skills を同期する
- ケースごと・エージェントごとに「今回だけの値」と貼り付け用プロンプトを作り、
  <出力先>/tokens.json に保存して画面にも表示する（verify_manual.py が照合に使う）
"""
import json
import os
import shutil
import subprocess
import sys
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / os.environ.get("MANUAL_OUT_DIR", ".manual_out")  # テストは別ディレクトリを使う
SKILL = "python-excel-spec"
AGENTS = ["claude", "codex"]

# id: (件名, プロンプト雛形, 値の雛形)   {skill} {rel} {value} を置換
CASES = {
    "M-03": ("名指し実行",
             "{skill} スキルを使って、{rel} の A1 に {value} を書き込み、読み戻して確認してください。終わったら DONE とだけ答えて。",
             "{token}"),
    "M-04": ("暗黙トリガー（スキル名を出さない）",
             "Excelファイル {rel} を新規作成し、A1 に {value} を入れて保存してください。終わったら DONE とだけ答えて。",
             "{token}"),
    "M-06": ("異常系（存在しないファイル）",
             "{rel} の A1 の値を読んで教えてください。",
             None),
    "M-07": ("日本語・絵文字",
             "{skill} スキルを使って、{rel} の A1 に「{value}」を書き込んでください。終わったら DONE とだけ答えて。",
             "うさうさ研修工房🐰{token}"),
}


def main():
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir()
    subprocess.run([sys.executable, str(ROOT / "scripts" / "sync_claude_links.py")], check=True)
    data = {}
    print("\n=== 貼り付け用プロンプト（各エージェントの対話画面にそのまま貼る） ===")
    for cid, (title, tmpl, vtmpl) in CASES.items():
        data[cid] = {}
        print(f"\n--- {cid} {title} ---")
        for agent in AGENTS:
            token = uuid.uuid4().hex[:8]
            rel = f"{OUT.name}/{cid.replace('-', '')}_{agent}.xlsx"
            value = vtmpl.format(token=token) if vtmpl else None
            prompt = tmpl.format(skill=SKILL, rel=rel, value=value)
            data[cid][agent] = {"file": rel, "value": value, "prompt": prompt}
            print(f"[{agent}] {prompt}")
    (OUT / "tokens.json").write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    print("\n準備完了。実施後は  python scripts/verify_manual.py <ケースID> <claude|codex>  で成果物を確認。")


if __name__ == "__main__":
    main()
