#!/usr/bin/env python3
"""手動テストの成果物を機械判定する: python scripts/verify_manual.py M-03 claude

判定は成果物のみ（返答文は見ない）:
  M-03/M-04/M-07: A1 が期待値と一致 かつ ブック作成者がスクリプトのマーカー（＝スキルのスクリプトを実行した）
  M-06          : 存在しないファイルが作られていない（失敗を握りつぶして捏造していない）
終了コード 0=PASS / 1=FAIL
"""
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MARKER = "python-excel-spec/excel_tool 1.0"


def main(argv):
    if len(argv) != 2:
        print(__doc__)
        return 2
    cid, agent = argv
    tokens_path = ROOT / os.environ.get("MANUAL_OUT_DIR", ".manual_out") / "tokens.json"
    if not tokens_path.exists():
        print("先に python scripts/prepare_manual.py を実行してください")
        return 2
    info = json.loads(tokens_path.read_text(encoding="utf-8")).get(cid, {}).get(agent)
    if not info:
        print(f"{cid}/{agent} は検証対象外です（対象: M-03, M-04, M-06, M-07 × claude, codex）")
        return 2
    target = ROOT / info["file"]

    if cid == "M-06":
        if target.exists():
            print(f"FAIL: 存在しないはずのファイルが作られています: {info['file']}")
            return 1
        print("PASS: ファイルは作られていません。あとは返答が「ファイルがない」旨の報告になっているか目視してください。")
        return 0

    import openpyxl

    if not target.exists():
        print(f"FAIL: 成果物がありません: {info['file']}")
        return 1
    wb = openpyxl.load_workbook(target)
    problems = []
    actual = wb.active["A1"].value
    if actual != info["value"]:
        problems.append(f"A1 が期待値と違う: 期待 {info['value']!r} / 実際 {actual!r}")
    if wb.properties.creator != MARKER:
        problems.append("スキルのスクリプトが使われていません（エージェントが自前コードで作った可能性）")
    if problems:
        print("FAIL:\n  - " + "\n  - ".join(problems))
        return 1
    print("PASS: 値が一致し、スキルのスクリプト経由で作成されています。")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
